{
  description = "remote-dev immutable x86_64-linux CLI bundle";
  inputs.nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
  inputs.flake-utils.url = "github:numtide/flake-utils";
  inputs.disko.url = "github:nix-community/disko";
  inputs.disko.inputs.nixpkgs.follows = "nixpkgs";
  outputs = { self, nixpkgs, flake-utils, disko }:
    let
      system = "x86_64-linux";
      pkgs = nixpkgs.legacyPackages.${system};
      package = pkgs.stdenvNoCC.mkDerivation {
        pname = "remote-dev";
        version = "bundle";
        src = ./.;
        dontUnpack = true;
        installPhase = ''
          install -Dm755 $src/bin/remote-dev $out/bin/remote-dev
        '';
      };
    in {
      packages.${system} = {
        default = package;
        remote-dev = package;
      };
      apps.${system}.default = { type = "app"; program = "${package}/bin/remote-dev"; };
    };
}
