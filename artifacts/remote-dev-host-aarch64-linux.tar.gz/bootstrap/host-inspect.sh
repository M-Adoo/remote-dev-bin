#!/bin/sh
set -eu

INSTALL_PROOF_PATH="${REMOTE_DEV_HOST_INSTALL_PROOF:-/etc/remote-dev/host-install-proof.json}"
LEASE_GROUP="${REMOTE_DEV_LEASE_GROUP:-remote-dev-lease}"
MOSH_UDP_FIREWALL_CAPABILITY="mosh-udp-60000-61000"
AGENT_RUNTIME_ROOT="/var/lib/remote-dev/runtime/agent/current"
LEASE_PREPARE_EXECUTOR="/etc/remote-dev/host-control/lease-prepare-v2"

command_exists() {
  command -v "$1" >/dev/null 2>&1
}

agent_runtime_binaries_ready() {
  [ -x "$AGENT_RUNTIME_ROOT/bin/remote-dev" ] && [ -x "$AGENT_RUNTIME_ROOT/bin/remote-dev-runtime" ]
}

json_escape() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

json_string() {
  printf '"'
  json_escape "$1"
  printf '"'
}

json_optional_string() {
  if [ -n "${1:-}" ]; then
    json_string "$1"
  else
    printf 'null'
  fi
}

json_optional_int() {
  case "${1:-}" in
    ''|*[!0-9-]*) printf 'null' ;;
    *) printf '%s' "$1" ;;
  esac
}

proof_string() {
  key="$1"
  if [ ! -r "$INSTALL_PROOF_PATH" ]; then
    return 0
  fi
  sed -n 's/.*"'"$key"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$INSTALL_PROOF_PATH" | sed -n '1p'
}

proof_int() {
  key="$1"
  if [ ! -r "$INSTALL_PROOF_PATH" ]; then
    return 0
  fi
  sed -n 's/.*"'"$key"'"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' "$INSTALL_PROOF_PATH" | sed -n '1p'
}

proof_bool() {
  key="$1"
  if [ ! -r "$INSTALL_PROOF_PATH" ]; then
    printf 'false'
    return 0
  fi
  value="$(sed -n 's/.*"'"$key"'"[[:space:]]*:[[:space:]]*\(true\|false\).*/\1/p' "$INSTALL_PROOF_PATH" | sed -n '1p')"
  case "$value" in
    true) printf 'true' ;;
    *) printf 'false' ;;
  esac
}

system_hostname() {
  hostname -f 2>/dev/null || hostname 2>/dev/null || true
}

read_host_key() {
  for path in \
    /etc/ssh/ssh_host_ed25519_key.pub \
    /etc/ssh/ssh_host_ecdsa_key.pub \
    /etc/ssh/ssh_host_rsa_key.pub
  do
    if [ -r "$path" ]; then
      sed -n '1s/[[:space:]]*$//p' "$path"
      return 0
    fi
  done
}

cpu_count() {
  count="$(getconf _NPROCESSORS_ONLN 2>/dev/null || printf '1')"
  case "$count" in
    ''|*[!0-9]*) printf '1' ;;
    *) printf '%s' "$count" ;;
  esac
}

memory_mb() {
  awk '/^MemTotal:/ { mb = int($2 / 1024); if (mb < 1) mb = 1; print mb; found = 1 } END { if (!found) print 1024 }' /proc/meminfo 2>/dev/null || printf '1024'
}

root_disk_gb() {
  df -Pk / 2>/dev/null | awk 'NR == 2 { gb = int($2 / 1024 / 1024); if (gb < 1) gb = 1; print gb; found = 1 } END { if (!found) print 1 }'
}

nix_conf_trusts_lease_group() {
  [ -r /etc/nix/nix.conf ] || return 1
  awk -v group="@$LEASE_GROUP" '
    /^[[:space:]]*trusted-users[[:space:]]*=/ {
      sub(/^[^=]*=/, "", $0)
      for (i = 1; i <= NF; i++) {
        if ($i == group) found = 1
      }
    }
    END { exit(found ? 0 : 1) }
  ' /etc/nix/nix.conf
}

iptables_check() {
  command_exists iptables || return 1
  iptables "$@" >/dev/null 2>&1
}

mosh_udp_firewall_allows_ports() {
  iptables_check -C nixos-fw -p udp --dport 60000:61000 -j nixos-fw-accept \
    || iptables_check -C nixos-fw -p udp --dport 60000:61000 -j ACCEPT \
    || iptables_check -C INPUT -p udp --dport 60000:61000 -j ACCEPT
}

CAPABILITIES=""
add_capability() {
  CAPABILITIES="${CAPABILITIES}${CAPABILITIES:+
}$1"
}

add_capability_if() {
  if "$@"; then
    add_capability "$1"
  fi
}

collect_capabilities() {
  add_capability ssh
  command_exists nix && add_capability nix
  command_exists systemctl && add_capability systemd
  command_exists systemd-nspawn && add_capability nspawn
  [ -e /sys/fs/cgroup/cgroup.controllers ] && add_capability cgroup-v2
  [ -e /proc/self/uid_map ] && add_capability user-namespace
  command_exists ip && add_capability private-network
  command_exists mosh-server && add_capability mosh-server
  mosh_udp_firewall_allows_ports && add_capability "$MOSH_UDP_FIREWALL_CAPABILITY"
  command_exists remote-dev && add_capability remote-dev-cli
  [ -e /var/lib/remote-dev/templates/nspawn-v1 ] && add_capability nspawn-template-v1
  command_exists useradd && add_capability lease-users
  nix_conf_trusts_lease_group && add_capability lease-users-trusted-nix
  [ -e /etc/NIXOS ] && add_capability nixos
  agent_runtime_binaries_ready && add_capability remote-dev-agent-runtime
  [ -x "$LEASE_PREPARE_EXECUTOR" ] && add_capability lease-prepare-plan-v2
}

print_capabilities_json() {
  printf '['
  printf '%s\n' "$CAPABILITIES" | sort -u | awk 'NF { print }' | {
    first=true
    while IFS= read -r capability; do
      if [ "$first" = true ]; then
        first=false
      else
        printf ','
      fi
      json_string "$capability"
    done
  }
  printf ']'
}

inspect_host() {
  collect_capabilities
  ssh_host="$(system_hostname | sed -n '1p')"
  host_key="$(read_host_key | sed -n '1p')"
  host_config_id="$(proof_string host_config_id)"
  image_contract_id="$(proof_string image_contract_id)"
  disk_count="$(proof_int disk_count)"
  flake_lock_hash="$(proof_string flake_lock_hash)"
  disko_layout_id="$(proof_string disko_layout_id)"
  current_system="$(proof_string current_system)"
  if [ -z "$current_system" ]; then
    current_system="$(nix eval --raw --impure --expr builtins.currentSystem 2>/dev/null || true)"
  fi
  install_id="$(proof_string install_id)"
  install_source="$(proof_string install_source)"
  clean_install="$(proof_bool clean_install)"
  lease_prepare_sha256=""
  if command_exists sha256sum && [ -r "$LEASE_PREPARE_EXECUTOR" ]; then
    lease_prepare_sha256="$(sha256sum "$LEASE_PREPARE_EXECUTOR" 2>/dev/null | awk '{print $1}' || true)"
  fi
  # aws-embed-strip-begin
  script_sha256=""
  if command_exists sha256sum && [ -r "$0" ]; then
    script_sha256="$(sha256sum "$0" 2>/dev/null | awk '{print $1}' || true)"
  fi
  # aws-embed-strip-end

  printf '{'
  printf '"ssh_host":'; json_optional_string "$ssh_host"
  printf ',"host_key":'; json_optional_string "$host_key"
  printf ',"cpu":%s' "$(cpu_count)"
  printf ',"memory_mb":%s' "$(memory_mb)"
  printf ',"disk_gb":%s' "$(root_disk_gb)"
  printf ',"capabilities":'; print_capabilities_json
  printf ',"host_config_id":'; json_optional_string "$host_config_id"
  printf ',"image_contract_id":'; json_optional_string "$image_contract_id"
  printf ',"disk_count":'; json_optional_int "$disk_count"
  printf ',"flake_lock_hash":'; json_optional_string "$flake_lock_hash"
  printf ',"disko_layout_id":'; json_optional_string "$disko_layout_id"
  printf ',"current_system":'; json_optional_string "$current_system"
  printf ',"host_control_source":"host_service_embedded"'
  # aws-embed-strip-begin
  printf ',"host_control_script_sha256":'; json_optional_string "$script_sha256"
  # aws-embed-strip-end
  printf ',"install_id":'; json_optional_string "$install_id"
  printf ',"install_source":'; json_optional_string "$install_source"
  printf ',"clean_install":%s' "$clean_install"
  printf ',"lease_prepare_schema_version":2'
  printf ',"lease_prepare_executor_sha256":'; json_optional_string "$lease_prepare_sha256"
  printf '}\n'
}

# aws-embed-strip-begin
probe_host() {
  [ -r "$INSTALL_PROOF_PATH" ] || {
    printf '%s\n' "missing remote-dev host install proof: $INSTALL_PROOF_PATH" >&2
    return 1
  }
  [ -n "$(read_host_key | sed -n '1p')" ] || {
    printf '%s\n' "ssh host key is not available" >&2
    return 1
  }
  for command in chown getent groupadd id loginctl systemd-run useradd usermod; do
    command_exists "$command" || {
      printf '%s\n' "missing required command: $command" >&2
      return 1
    }
  done
  nix_conf_trusts_lease_group || {
    printf '%s\n' "nix trusted-users does not include @$LEASE_GROUP" >&2
    return 1
  }
  printf '{"healthy":true}\n'
}
# aws-embed-strip-end

case "${1:-inspect-host}" in
  inspect-host)
    inspect_host
    ;;
  # aws-embed-strip-begin
  probe-host)
    shift
    probe_host "$@"
    ;;
  # aws-embed-strip-end
  *)
    printf '%s\n' "unsupported host inspection command: ${1:-}" >&2
    exit 64
    ;;
esac
