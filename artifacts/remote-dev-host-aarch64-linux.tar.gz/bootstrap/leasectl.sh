#!/bin/sh
set -eu

LEASE_GROUP="${REMOTE_DEV_LEASE_GROUP:-remote-dev-lease}"
HOME_ROOT="${REMOTE_DEV_LEASE_HOME_ROOT:-/var/lib/remote-dev/leases}"
HOST_RUNTIME_PATH="/var/lib/remote-dev/runtime/agent/current/bin:/run/current-system/sw/bin:/usr/bin:/bin:/usr/sbin:/sbin"
TEST_MODE="${REMOTE_DEV_LEASE_TEST_MODE:-0}"

case "$TEST_MODE" in 0|1) ;; *) printf '%s\n' "REMOTE_DEV_LEASE_TEST_MODE must be 0 or 1" >&2; exit 1 ;; esac

fail() {
  printf '%s\n' "$*" >&2
  exit 1
}

run_admin() {
  "$@" 1>&2
}

validate_name() {
  label="$1"
  value="$2"
  case "$value" in
    ''|*[^A-Za-z0-9._-]*)
      fail "$label must contain only ASCII letters, numbers, '.', '_' or '-'"
      ;;
  esac
}

lease_dir() {
  printf '%s/%s' "$HOME_ROOT" "$LEASE_ID"
}

lease_home() {
  printf '%s/root' "$(lease_dir)"
}

lease_shell_path() {
  printf '%s/login-shell' "$(lease_dir)"
}

lease_ssh_command_path() {
  printf '%s/ssh-command' "$(lease_dir)"
}

lease_command_bin() {
  printf '%s/.remote-dev/host/bin' "$(lease_home)"
}

select_login_shell() {
  for shell in /run/current-system/sw/bin/bash /bin/bash /bin/sh; do
    if [ -x "$shell" ]; then
      printf '%s' "$shell"
      return 0
    fi
  done
  printf '%s' /bin/sh
}

ensure_group() {
  if getent group "$LEASE_GROUP" >/dev/null 2>&1; then
    return 0
  fi
  run_admin groupadd --system "$LEASE_GROUP" || return 1
}

user_exists() {
  id -u "$1" >/dev/null 2>&1
}

ensure_user_group() {
  run_admin usermod -a -G "$LEASE_GROUP" "$UNIX_USER" || return 1
}

ensure_lease_user() {
  lease_root="$(lease_dir)"
  mkdir -p "$lease_root" || return 1
  chmod 711 "$HOME_ROOT" "$lease_root" || return 1
  ensure_group || return 1
  if user_exists "$UNIX_USER"; then
    ensure_user_group || return 1
    return 0
  fi
  run_admin useradd \
    --home-dir "$(lease_home)" \
    --create-home \
    --shell "$(select_login_shell)" \
    --gid "$LEASE_GROUP" \
    --password x \
    --comment "remote-dev lease $LEASE_ID" \
    "$UNIX_USER" || return 1
}

ensure_user_manager() {
  run_admin loginctl enable-linger "$UNIX_USER" || return 1
}

write_shell_wrapper() {
  path="$(lease_shell_path)"
  command_bin="$(lease_command_bin)"
  real_shell="$(select_login_shell)"
  mkdir -p "$(dirname "$path")" || return 1
  cat > "$path" <<EOF
#!/bin/sh
export PATH=$command_bin:$HOST_RUNTIME_PATH:\${PATH:-}
exec $real_shell "\$@"
EOF
  chmod 755 "$path" || return 1
}

write_ssh_command_wrapper() {
  path="$(lease_ssh_command_path)"
  command_bin="$(lease_command_bin)"
  real_shell="$(select_login_shell)"
  mkdir -p "$(dirname "$path")" || return 1
  cat > "$path" <<EOF
#!/bin/sh
export PATH=$command_bin:$HOST_RUNTIME_PATH:\${PATH:-}
if [ -n "\${SSH_ORIGINAL_COMMAND:-}" ]; then
  exec $real_shell -c "\$SSH_ORIGINAL_COMMAND"
fi
exec $real_shell
EOF
  chmod 755 "$path" || return 1
}

ensure_base_environment() {
  write_shell_wrapper || return 1
  write_ssh_command_wrapper || return 1
  run_admin usermod --shell "$(lease_shell_path)" "$UNIX_USER" || return 1
}

authorized_keys_path() {
  printf '%s/.ssh/authorized_keys' "$(lease_home)"
}

managed_key_start() {
  printf '# remote-dev lease %s begin' "$LEASE_ID"
}

managed_key_end() {
  printf '# remote-dev lease %s end' "$LEASE_ID"
}

authorized_key_command_value() {
  printf '%s' "$(lease_ssh_command_path)" | sed 's/\\/\\\\/g; s/"/\\"/g'
}

managed_authorized_key_line() {
  key="$(printf '%s' "$PUBLIC_KEY" | sed -n '1p')"
  [ -n "$key" ] || fail "public key must be non-empty"
  [ "$key" = "$PUBLIC_KEY" ] || fail "public key must be a single authorized_keys line"
  printf 'command="%s" %s' "$(authorized_key_command_value)" "$key"
}

managed_authorized_key_block_ready() {
  path="$(authorized_keys_path)"
  [ -f "$path" ] || return 1
  start="$(managed_key_start)"
  end="$(managed_key_end)"
  awk -v start="$start" -v end="$end" '
    $0 == start { inside = 1; next }
    inside && $0 == end { closed = 1; inside = 0; next }
    inside && NF { found = 1 }
    END { exit(found && closed ? 0 : 1) }
  ' "$path"
}

remove_managed_authorized_key_block() {
  path="$(authorized_keys_path)"
  [ -f "$path" ] || return 0
  tmp="$path.tmp.$$"
  start="$(managed_key_start)"
  end="$(managed_key_end)"
  awk -v start="$start" -v end="$end" '
    $0 == start { skip = 1; next }
    $0 == end { skip = 0; next }
    !skip { print }
  ' "$path" > "$tmp" || return 1
  cat "$tmp" > "$path" || return 1
  rm -f "$tmp" || return 1
}

write_authorized_key() {
  ssh_dir="$(lease_home)/.ssh"
  mkdir -p "$ssh_dir" || return 1
  chmod 700 "$ssh_dir" || return 1
  path="$(authorized_keys_path)"
  touch "$path" || return 1
  chmod 600 "$path" || return 1
  remove_managed_authorized_key_block || return 1
  key_line="$(managed_authorized_key_line)" || return 1
  {
    cat "$path"
    printf '%s\n' "$(managed_key_start)"
    printf '%s\n' "$key_line"
    printf '%s\n' "$(managed_key_end)"
  } > "$path.tmp.$$" || return 1
  cat "$path.tmp.$$" > "$path" || return 1
  rm -f "$path.tmp.$$" || return 1
}

chown_home() {
  run_admin chown "$UNIX_USER:$LEASE_GROUP" "$(lease_home)" || return 1
  if [ -d "$(lease_home)/.ssh" ]; then
    run_admin chown "$UNIX_USER:$LEASE_GROUP" "$(lease_home)/.ssh" || return 1
  fi
  if [ -f "$(authorized_keys_path)" ]; then
    run_admin chown "$UNIX_USER:$LEASE_GROUP" "$(authorized_keys_path)" || return 1
  fi
}

prepare_access_steps() {
  prepare_status=0
  ensure_lease_user || prepare_status="$?"
  if [ "$prepare_status" -eq 0 ]; then ensure_user_manager || prepare_status="$?"; fi
  if [ "$prepare_status" -eq 0 ]; then ensure_base_environment || prepare_status="$?"; fi
  if [ "$prepare_status" -eq 0 ]; then write_authorized_key || prepare_status="$?"; fi
  if [ "$prepare_status" -eq 0 ]; then chown_home || prepare_status="$?"; fi
  if [ "$prepare_status" -eq 0 ]; then ensure_ready || prepare_status="$?"; fi
  return "$prepare_status"
}

ensure_ready() {
  user_exists "$UNIX_USER" || fail "lease unix user $UNIX_USER is not present after prepare"
  [ -d "$(lease_home)" ] || fail "lease home $(lease_home) is not a directory"
  managed_authorized_key_block_ready \
    || fail "lease authorized_keys is missing the managed attach key block"
  [ -x "$(lease_shell_path)" ] || fail "lease shell wrapper is not executable"
  [ -x "$(lease_ssh_command_path)" ] || fail "lease ssh command wrapper is not executable"
}

json_field() {
  key="$1"
  printf '%s' "$PLAN_JSON" \
    | sed -n 's/.*"'"$key"'":"\([^"]*\)".*/\1/p' \
    | sed -n '1p'
}

json_escape_value() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/^/"/; s/$/"/'
}

load_prepare_plan() {
  if [ -n "$INPUT_FILE" ]; then
    [ -f "$INPUT_FILE" ] || fail "lease prepare input file is missing"
    mode="$(stat -c '%a' "$INPUT_FILE" 2>/dev/null || true)"
    case "$mode" in 600|400) ;; *) fail "lease prepare input file must be root-only" ;; esac
    PLAN_JSON="$(dd if="$INPUT_FILE" bs=16385 count=1 2>/dev/null)"
  else
    PLAN_JSON="$(dd bs=16385 count=1 2>/dev/null)"
  fi
  [ "${#PLAN_JSON}" -le 16384 ] || fail "lease prepare plan exceeds 16384 bytes"
  case "$PLAN_JSON" in *'
'*) fail "lease prepare plan must be one JSON frame" ;; esac
  PLAN_ID="$(json_field plan_id)"
  SPEC_DIGEST="$(json_field spec_digest)"
  WORKSPACE_ID="$(json_field workspace_id)"
  LEASE_ID="$(json_field lease_id)"
  UNIX_USER="$(json_field unix_user)"
  PUBLIC_KEY="$(json_field attach_public_key)"
  ATTACH_KEY_FINGERPRINT="$(json_field attach_key_fingerprint)"
  OBJECT_FORMAT="$(json_field object_format)"
  SEED_HTTPS_URL="$(json_field anonymous_https_url)"
  SEED_SSH_URL="$(json_field ssh_url)"
  SEED_FETCH_REF="$(json_field fetch_ref)"
  SEED_EXPECTED_OID="$(json_field expected_commit_oid)"
  for value in "$PLAN_ID" "$SPEC_DIGEST" "$WORKSPACE_ID" "$LEASE_ID" "$UNIX_USER" \
    "$PUBLIC_KEY" "$ATTACH_KEY_FINGERPRINT"; do
    [ -n "$value" ] || fail "lease prepare plan is missing a required field"
  done
  validate_name plan_id "$PLAN_ID"
  validate_name spec_digest "$SPEC_DIGEST"
  validate_name workspace_id "$WORKSPACE_ID"
  validate_name lease_id "$LEASE_ID"
  validate_name unix_user "$UNIX_USER"
  [ "${#PLAN_ID}" -eq 64 ] || fail "lease prepare plan_id must be SHA-256"
  [ "${#SPEC_DIGEST}" -eq 64 ] || fail "lease prepare spec_digest must be SHA-256"
  [ "${#ATTACH_KEY_FINGERPRINT}" -eq 64 ] \
    || fail "lease prepare attach_key_fingerprint must be SHA-256"
  case "$PLAN_ID$SPEC_DIGEST$ATTACH_KEY_FINGERPRINT" in
    *[!0-9a-f]*) fail "lease prepare identity digests must be lowercase hexadecimal" ;;
  esac
  case "$PLAN_JSON" in
    *'"schema_version":3'*'"pre_workspace":'*) ;;
    *) fail "lease prepare plan schema must be v3" ;;
  esac
  case "$PUBLIC_KEY" in
    ssh-ed25519\ *) ;;
    *) fail "lease prepare attach_public_key must be one ssh-ed25519 key" ;;
  esac
  case "$PUBLIC_KEY" in *'
'*) fail "lease prepare attach_public_key must be one line" ;; esac
  actual_fingerprint="$(printf '%s' "$PUBLIC_KEY" | sha256sum | awk '{print $1}')"
  [ "$actual_fingerprint" = "$ATTACH_KEY_FINGERPRINT" ] \
    || fail "lease prepare attach_public_key does not match attach_key_fingerprint"
  if printf '%s' "$PLAN_JSON" | grep -q '"pre_workspace":null'; then
    [ -z "$OBJECT_FORMAT$SEED_HTTPS_URL$SEED_SSH_URL$SEED_FETCH_REF$SEED_EXPECTED_OID" ] \
      || fail "access-only lease prepare plan contains pre-workspace fields"
  else
    case "$OBJECT_FORMAT" in sha1|sha256) ;; *) fail "lease prepare object_format is invalid" ;; esac
    if [ -n "$SEED_HTTPS_URL$SEED_SSH_URL$SEED_FETCH_REF$SEED_EXPECTED_OID" ]; then
      [ -n "$SEED_HTTPS_URL$SEED_SSH_URL" ] \
        && [ -n "$SEED_FETCH_REF" ] \
        && [ -n "$SEED_EXPECTED_OID" ] \
        || fail "Git seed intent requires a candidate, fetch ref and expected OID"
    fi
  fi
}

bound_identity_json() {
  printf '{"workspace_id":%s,"lease_id":%s,"unix_user":%s,"attach_key_fingerprint":%s,"spec_digest":%s,"plan_id":%s}' \
    "$(json_escape_value "$WORKSPACE_ID")" \
    "$(json_escape_value "$LEASE_ID")" \
    "$(json_escape_value "$UNIX_USER")" \
    "$(json_escape_value "$ATTACH_KEY_FINGERPRINT")" \
    "$(json_escape_value "$SPEC_DIGEST")" \
    "$(json_escape_value "$PLAN_ID")"
}

control_dir() {
  printf '%s/control' "$(lease_dir)"
}

prepare_marker() {
  printf '%s/lease-prepare-v3.json' "$(control_dir)"
}

prepare_trace() {
  printf '%s/lease-prepare-v3-trace.json' "$(control_dir)"
}

prepare_lock_dir() {
  printf '%s/lease-prepare-v3.lock' "$(control_dir)"
}

ensure_control_dir() {
  directory="$(control_dir)"
  [ ! -L "$directory" ] || fail "lease prepare control directory must not be a symlink"
  install -d -m 0700 -o root -g root "$directory" || return 1
  [ ! -L "$directory" ] && [ -d "$directory" ] \
    || fail "lease prepare control directory is invalid"
  if [ "$TEST_MODE" = 0 ]; then
    metadata="$(stat -c '%u:%g:%a' "$directory" 2>/dev/null)" \
      || fail "lease prepare control directory metadata is unavailable"
    [ "$metadata" = 0:0:700 ] \
      || fail "lease prepare control directory must be root:root mode 0700"
  fi
}

release_prepare_lock() {
  lock="$(prepare_lock_dir)"
  [ -d "$lock" ] || return 0
  rm -f "$lock/pid"
  rmdir "$lock" 2>/dev/null || true
}

acquire_prepare_lock() {
  ensure_control_dir || return 1
  lock="$(prepare_lock_dir)"
  attempt=0
  while ! mkdir "$lock" 2>/dev/null; do
    [ ! -L "$lock" ] && [ -d "$lock" ] \
      || fail "lease prepare lock path is invalid"
    owner_pid="$(sed -n '1p' "$lock/pid" 2>/dev/null || true)"
    case "$owner_pid" in
      ''|*[!0-9]*) ;;
      *)
        if kill -0 "$owner_pid" 2>/dev/null; then
          fail "lease prepare is already running for lease $LEASE_ID"
        fi
        ;;
    esac
    [ "$attempt" -eq 0 ] || fail "lease prepare stale lock could not be recovered"
    rm -f "$lock/pid"
    rmdir "$lock" 2>/dev/null || fail "lease prepare lock is not recoverable"
    attempt=$((attempt + 1))
  done
  chmod 700 "$lock" || return 1
  umask 077
  printf '%s\n' "$$" > "$lock/pid" || return 1
  if [ "$TEST_MODE" = 0 ]; then
    chown root:root "$lock" "$lock/pid" || return 1
    chmod 600 "$lock/pid" || return 1
  fi
  trap 'release_prepare_lock' EXIT
  trap 'release_prepare_lock; exit 129' HUP
  trap 'release_prepare_lock; exit 130' INT
  trap 'release_prepare_lock; exit 143' TERM
}

write_prepare_marker() {
  phase="$1"
  receipt="${2:-}"
  ensure_control_dir || return 1
  marker="$(prepare_marker)"
  [ ! -L "$marker" ] && [ ! -L "$marker.next" ] \
    || fail "lease prepare marker path must not be a symlink"
  umask 077
  if [ -n "$receipt" ]; then
    printf '{"identity":%s,"phase":%s,"receipt":%s}\n' \
      "$(bound_identity_json)" "$(json_escape_value "$phase")" "$receipt" > "$marker.next"
  else
    printf '{"identity":%s,"phase":%s}\n' \
      "$(bound_identity_json)" "$(json_escape_value "$phase")" > "$marker.next"
  fi
  if [ "$TEST_MODE" = 0 ]; then
    chown root:root "$marker.next"
  fi
  chmod 600 "$marker.next"
  mv "$marker.next" "$marker"
}

marker_field() {
  key="$1"
  [ -r "$(prepare_marker)" ] || return 0
  sed -n 's/.*"'"$key"'":"\([^"]*\)".*/\1/p' "$(prepare_marker)" | sed -n '1p'
}

marker_phase() {
  marker_field phase
}

marker_matches_identity() {
  [ "$(marker_field workspace_id)" = "$WORKSPACE_ID" ] \
    && [ "$(marker_field lease_id)" = "$LEASE_ID" ] \
    && [ "$(marker_field unix_user)" = "$UNIX_USER" ] \
    && [ "$(marker_field attach_key_fingerprint)" = "$ATTACH_KEY_FINGERPRINT" ] \
    && [ "$(marker_field spec_digest)" = "$SPEC_DIGEST" ] \
    && [ "$(marker_field plan_id)" = "$PLAN_ID" ]
}

marker_receipt() {
  [ ! -L "$(prepare_marker)" ] || return 1
  marker_line="$(cat "$(prepare_marker)")"
  receipt="${marker_line#*\"receipt\":}"
  [ "$receipt" != "$marker_line" ] || return 1
  receipt="${receipt%?}"
  printf '%s' "$receipt"
}

write_prepare_trace() {
  trace="$1"
  ensure_control_dir || return 1
  path="$(prepare_trace)"
  [ ! -L "$path" ] && [ ! -L "$path.next" ] \
    || fail "lease prepare trace path must not be a symlink"
  umask 077
  printf '%s\n' "$trace" > "$path.next" || return 1
  if [ "$TEST_MODE" = 0 ]; then
    chown root:root "$path.next" || return 1
  fi
  chmod 600 "$path.next" || return 1
  mv "$path.next" "$path"
}

stored_prepare_trace() {
  path="$(prepare_trace)"
  [ ! -L "$path" ] && [ -f "$path" ] && [ -r "$path" ] || return 1
  if [ "$TEST_MODE" = 0 ]; then
    metadata="$(stat -c '%u:%g:%a' "$path" 2>/dev/null || true)"
    [ "$metadata" = 0:0:600 ] || return 1
  fi
  trace="$(cat "$path")" || return 1
  case "$trace" in
    *'
'*) return 1 ;;
  esac
  trace_plan_id="$(printf '%s' "$trace" \
    | sed -n 's/.*"plan_id":"\([^"]*\)".*/\1/p' \
    | sed -n '1p')"
  [ "$trace_plan_id" = "$PLAN_ID" ] || return 1
  printf '%s' "$trace"
}

emit_access_ready() {
  printf '{"event":"lease_access_ready_v2","schema_version":2,"identity":%s,"remote_home":%s}\n' \
    "$(bound_identity_json)" "$(json_escape_value "$(lease_home)")"
}

emit_completed() {
  receipt="$1"
  execution_trace="$2"
  printf '{"event":"lease_prepare_completed_v2","schema_version":2,"receipt":%s,"execution_trace":%s}\n' \
    "$receipt" "$execution_trace"
}

emit_failed() {
  phase="$1"
  reason="$2"
  cleanup_status="$3"
  printf '{"event":"lease_prepare_failed_v2","schema_version":2,"identity":%s,"phase":%s,"reason_code":%s,"cleanup_status":%s}\n' \
    "$(bound_identity_json)" "$(json_escape_value "$phase")" "$(json_escape_value "$reason")" \
    "$(json_escape_value "$cleanup_status")"
}

wait_for_git() {
  if [ "$TEST_MODE" = 1 ] && [ -n "${REMOTE_DEV_LEASE_TEST_GIT_PATH:-}" ]; then
    GIT_PATH="$REMOTE_DEV_LEASE_TEST_GIT_PATH"
    RUNTIME_PATH="${REMOTE_DEV_LEASE_TEST_RUNTIME_PATH:-/var/lib/remote-dev/runtime/agent/current/bin/remote-dev-runtime}"
    [ -x "$GIT_PATH" ] || return 1
    [ -x "$RUNTIME_PATH" ] || return 1
    return 0
  fi
  deadline=$(( $(date +%s) + 180 ))
  runtime=/var/lib/remote-dev/runtime/agent/current/bin/remote-dev-runtime
  catalog=/etc/remote-dev/host-groups-catalog.json
  if [ "$TEST_MODE" = 1 ]; then
    runtime="${REMOTE_DEV_LEASE_TEST_RUNTIME_PATH:-$runtime}"
    catalog="${REMOTE_DEV_LEASE_TEST_CATALOG_PATH:-$catalog}"
    if [ -n "${REMOTE_DEV_LEASE_TEST_GIT_WAIT_READY_PATH:-}" ]; then
      : > "$REMOTE_DEV_LEASE_TEST_GIT_WAIT_READY_PATH"
    fi
  fi
  while [ ! -x "$runtime" ] || [ ! -r "$catalog" ]; do
    [ "$(date +%s)" -lt "$deadline" ] || return 1
    sleep 0.05
  done
  RUNTIME_PATH="$runtime"
  GIT_PATH="$("$runtime" wait --scope host --command git --timeout 120 2>/dev/null | sed -n '1p')"
  [ -x "$GIT_PATH" ]
}

run_as_lease_user() {
  runuser -u "$UNIX_USER" -- env \
    HOME="$(lease_home)" \
    USER="$UNIX_USER" \
    PATH="$(dirname "$GIT_PATH"):/run/current-system/sw/bin:/usr/bin:/bin" \
    GIT_CONFIG_NOSYSTEM=1 \
    GIT_TERMINAL_PROMPT=0 \
    GCM_INTERACTIVE=never \
    http_proxy= https_proxy= HTTP_PROXY= HTTPS_PROXY= ALL_PROXY= all_proxy= \
    "$@"
}

repo_path() {
  printf '%s/.remote-dev/workspaces/%s/repo' "$(lease_home)" "$WORKSPACE_ID"
}

write_git_wrappers() {
  bin="$(lease_command_bin)"
  run_as_lease_user mkdir -p "$bin"
  for command in git git-receive-pack git-upload-pack; do
    case "$command" in
      git) subcommand= ;;
      git-receive-pack) subcommand=receive-pack ;;
      git-upload-pack) subcommand=upload-pack ;;
    esac
    path="$bin/$command"
    {
      printf '%s\n' '#!/bin/sh'
      if [ -n "$subcommand" ]; then
        printf 'exec %s %s "$@"\n' "$GIT_PATH" "$subcommand"
      else
        printf 'exec %s "$@"\n' "$GIT_PATH"
      fi
    } > "$path.next"
    chown "$UNIX_USER:$LEASE_GROUP" "$path.next"
    chmod 755 "$path.next"
    mv "$path.next" "$path"
  done
}

prepare_repo_target() {
  case "$OBJECT_FORMAT" in sha1|sha256) ;; *) return 1 ;; esac
  repo="$(repo_path)"
  parent="$(dirname "$repo")"
  case "$repo" in "$(lease_home)/.remote-dev/workspaces/$WORKSPACE_ID/repo") ;; *) return 1 ;; esac
  [ ! -L "$(lease_home)" ] \
    && [ ! -L "$(lease_home)/.remote-dev" ] \
    && [ ! -L "$(lease_home)/.remote-dev/workspaces" ] \
    && [ ! -L "$parent" ] || return 1
  run_as_lease_user mkdir -p "$parent" || return 1
  [ ! -L "$parent" ] || return 1
  if [ ! -e "$repo" ]; then
    run_as_lease_user "$GIT_PATH" init \
      "--object-format=$OBJECT_FORMAT" \
      --initial-branch=remote-dev-prepared \
      "$repo" >/dev/null 2>&1 || return 1
  fi
  verify_repo_target || return 1
  run_as_lease_user "$GIT_PATH" -C "$repo" config receive.denyCurrentBranch updateInstead || return 1
  run_as_lease_user "$GIT_PATH" -C "$repo" config user.name remote-dev-runtime || return 1
  run_as_lease_user "$GIT_PATH" -C "$repo" config user.email runtime@remote-dev.invalid || return 1
  write_git_wrappers || return 1
}

verify_repo_target() {
  repo="$(repo_path)"
  [ -d "$repo/.git" ] && [ ! -L "$repo" ] && [ ! -L "$repo/.git" ] || return 1
  actual_format="$(run_as_lease_user "$GIT_PATH" -C "$repo" rev-parse --show-object-format 2>/dev/null)" \
    || return 1
  [ "$actual_format" = "$OBJECT_FORMAT" ] || return 1
  head_ref="$(run_as_lease_user "$GIT_PATH" -C "$repo" symbolic-ref -q HEAD 2>/dev/null)" || return 1
  [ "$head_ref" = refs/heads/remote-dev-prepared ] || return 1
  if run_as_lease_user "$GIT_PATH" -C "$repo" rev-parse --verify -q HEAD >/dev/null 2>&1; then
    return 1
  fi
}

# aws-embed-strip-begin
terminate_user_processes() {
  user="$1"
  user_exists "$user" || return 0
  pkill -TERM -u "$user" >/dev/null 2>&1 || true
  i=0
  while [ "$i" -lt 10 ]; do
    if ! pgrep -u "$user" >/dev/null 2>&1; then
      return 0
    fi
    sleep 0.05
    i=$((i + 1))
  done
  pkill -KILL -u "$user" >/dev/null 2>&1 || true
}

cleanup_access() {
  remove_home="${1:-$REMOVE_HOME}"
  validate_name lease_id "$LEASE_ID"
  validate_name unix_user "$UNIX_USER"
  remove_managed_authorized_key_block || true
  loginctl disable-linger "$UNIX_USER" >/dev/null 2>&1 || true
  terminate_user_processes "$UNIX_USER"
  if user_exists "$UNIX_USER"; then
    userdel "$UNIX_USER"
  fi
  if [ "$remove_home" = true ]; then
    rm -rf "$(lease_dir)"
  fi
}
# aws-embed-strip-end

git_seed_id_v17() {
  format_tag=1
  [ "$OBJECT_FORMAT" = sha256 ] && format_tag=2
  {
    printf 'remote-dev/git-seed-intent/v1\0'
    printf "\\$(printf '%03o' "$format_tag")"
    for value in "$SEED_FETCH_REF" "$SEED_EXPECTED_OID"; do
      length="${#value}"
      printf "\\$(printf '%03o' $(( (length >> 24) & 255 )))"
      printf "\\$(printf '%03o' $(( (length >> 16) & 255 )))"
      printf "\\$(printf '%03o' $(( (length >> 8) & 255 )))"
      printf "\\$(printf '%03o' $(( length & 255 )))"
      printf '%s' "$value"
    done
    for value in "$SEED_HTTPS_URL" "$SEED_SSH_URL"; do
      if [ -n "$value" ]; then
        printf '\001'
        length="${#value}"
        printf "\\$(printf '%03o' $(( (length >> 24) & 255 )))"
        printf "\\$(printf '%03o' $(( (length >> 16) & 255 )))"
        printf "\\$(printf '%03o' $(( (length >> 8) & 255 )))"
        printf "\\$(printf '%03o' $(( length & 255 )))"
        printf '%s' "$value"
      else
        printf '\000'
      fi
    done
  } | sha256sum | awk '{print $1}'
}

json_output_field() {
  json="$1"
  key="$2"
  printf '%s' "$json" \
    | sed -n 's/.*"'"$key"'":"\([^"]*\)".*/\1/p' \
    | sed -n '1p'
}

json_output_u64() {
  json="$1"
  key="$2"
  value="$(printf '%s' "$json" \
    | sed -n 's/.*"'"$key"'":\([0-9][0-9]*\).*/\1/p' \
    | sed -n '1p')"
  case "$value" in ''|*[!0-9]*) printf '0' ;; *) printf '%s' "$value" ;; esac
}

json_output_optional_u64() {
  json="$1"
  key="$2"
  printf '%s' "$json" \
    | sed -n 's/.*"'"$key"'":\([0-9][0-9]*\).*/\1/p' \
    | sed -n '1p'
}

json_output_bool() {
  json="$1"
  key="$2"
  printf '%s' "$json" \
    | sed -n 's/.*"'"$key"'":\(true\|false\).*/\1/p' \
    | sed -n '1p'
}

git_seed_request_json() {
  if [ -n "$SEED_HTTPS_URL" ]; then
    https_field="$(printf ',"anonymous_https_url":%s' \
      "$(json_escape_value "$SEED_HTTPS_URL")")"
  else
    https_field=
  fi
  if [ -n "$SEED_SSH_URL" ]; then
    ssh_field="$(printf ',"ssh_url":%s' "$(json_escape_value "$SEED_SSH_URL")")"
  else
    ssh_field=
  fi
  printf \
    '{"schema_version":1,"operation_id":%s,"repo":%s,"object_format":%s,"intent":{"schema_version":1,"fetch_ref":%s,"expected_commit_oid":%s%s%s},"transport":"anonymous_https"}' \
    "$(json_escape_value "$PLAN_ID")" \
    "$(json_escape_value "$(repo_path)")" \
    "$(json_escape_value "$OBJECT_FORMAT")" \
    "$(json_escape_value "$SEED_FETCH_REF")" \
    "$(json_escape_value "$SEED_EXPECTED_OID")" \
    "$https_field" \
    "$ssh_field"
}

prepare_anonymous_seed() {
  SEED_RESULT=not_requested
  SEED_REASON=
  SEED_ID=
  SEED_FETCH_BYTES=0
  SEED_IMPORT_BYTES=0
  SEED_OBJECT_COUNT=0
  SEED_FIRST_RESPONSE_MS=
  SEED_MAX_INACTIVITY_MS=0
  SEED_STARTED_AT_MS="$(seed_now_ms)"
  if [ -z "$SEED_HTTPS_URL$SEED_SSH_URL" ]; then
    SEED_FINISHED_AT_MS="$SEED_STARTED_AT_MS"
    SEED_DURATION_MS=0
    return 0
  fi

  SEED_ID="$(git_seed_id_v17)"
  if [ -z "$SEED_HTTPS_URL" ]; then
    SEED_RESULT=deferred
    SEED_REASON=candidate_absent
    SEED_FINISHED_AT_MS="$(seed_now_ms)"
    SEED_DURATION_MS=$((SEED_FINISHED_AT_MS - SEED_STARTED_AT_MS))
    return 0
  fi

  request="$(git_seed_request_json)" || return 1
  set +e
  output="$(printf '%s' "$request" \
    | run_as_lease_user "$RUNTIME_PATH" git-seed --input - 2>/dev/null)"
  status="$?"
  set -e
  SEED_FINISHED_AT_MS="$(seed_now_ms)"
  SEED_DURATION_MS=$((SEED_FINISHED_AT_MS - SEED_STARTED_AT_MS))
  [ "$status" -eq 0 ] || return 1
  [ "$(json_output_field "$output" operation_id)" = "$PLAN_ID" ] || return 1
  [ "$(json_output_field "$output" seed_id)" = "$SEED_ID" ] || return 1
  [ "$(json_output_field "$output" transport)" = anonymous_https ] || return 1
  [ "$(json_output_bool "$output" cleanup_confirmed)" = true ] || return 1
  result="$(json_output_field "$output" kind)"
  case "$result" in
    ready)
      [ "$(json_output_field "$output" fetched_oid)" = "$SEED_EXPECTED_OID" ] || return 1
      SEED_RESULT=ready
      ;;
    deferred)
      SEED_REASON="$(json_output_field "$output" reason_code)"
      [ -n "$SEED_REASON" ] || return 1
      SEED_RESULT=deferred
      ;;
    *) return 1 ;;
  esac
  SEED_FIRST_RESPONSE_MS="$(json_output_optional_u64 "$output" first_response_ms)"
  SEED_MAX_INACTIVITY_MS="$(json_output_u64 "$output" max_inactivity_ms)"
  SEED_FETCH_BYTES="$(json_output_u64 "$output" fetch_bytes)"
  SEED_IMPORT_BYTES="$(json_output_u64 "$output" import_bytes)"
  SEED_OBJECT_COUNT="$(json_output_u64 "$output" object_count)"
}

seed_now_ms() {
  date +%s%3N
}

build_receipt() {
  identity="$(bound_identity_json)"
  if printf '%s' "$PLAN_JSON" | grep -q '"pre_workspace":null'; then
    printf '{"schema_version":2,"identity":%s,"access_ready":true,"pre_workspace":{"kind":"not_requested"}}' \
      "$identity"
    return
  fi
  case "$SEED_RESULT" in
    not_requested)
      seed='{"kind":"not_requested"}'
      ;;
    ready)
      seed="$(printf '{"kind":"ready","seed_id":%s,"fetched_oid":%s}' \
        "$(json_escape_value "$SEED_ID")" "$(json_escape_value "$SEED_EXPECTED_OID")")"
      ;;
    deferred)
      seed="$(printf '{"kind":"deferred","seed_id":%s,"reason_code":%s}' \
        "$(json_escape_value "$SEED_ID")" "$(json_escape_value "$SEED_REASON")")"
      ;;
    *) return 1 ;;
  esac
  printf '{"schema_version":2,"identity":%s,"access_ready":true,"pre_workspace":{"kind":"prepared","repo_target":{"repo_layout_version":1,"object_format":%s},"seed":%s}}' \
    "$identity" "$(json_escape_value "$OBJECT_FORMAT")" "$seed"
}

phase_trace_json() {
  started_at_ms="$1"
  duration_ms="$2"
  printf '{"started_at_ms":%s,"duration_ms":%s}' "$started_at_ms" "$duration_ms"
}

build_execution_trace() {
  access="$(phase_trace_json "$ACCESS_STARTED_AT_MS" "$ACCESS_DURATION_MS")"
  if printf '%s' "$PLAN_JSON" | grep -q '"pre_workspace":null'; then
    git_runtime_wait=null
    repo_target=null
    anonymous_https=null
  else
    git_runtime_wait="$(phase_trace_json \
      "$GIT_RUNTIME_WAIT_STARTED_AT_MS" "$GIT_RUNTIME_WAIT_DURATION_MS")"
    repo_target="$(phase_trace_json "$REPO_TARGET_STARTED_AT_MS" "$REPO_TARGET_DURATION_MS")"
    if [ -z "$SEED_HTTPS_URL$SEED_SSH_URL" ]; then
      anonymous_https=null
    else
      case "$SEED_RESULT" in
        ready)
          seed_outcome='{"kind":"ready"}'
          ;;
        deferred)
          seed_outcome="$(printf '{"kind":"deferred","reason_code":%s}' \
            "$(json_escape_value "$SEED_REASON")")"
          ;;
        *) return 1 ;;
      esac
      if [ -n "$SEED_FIRST_RESPONSE_MS" ]; then
        first_response="$SEED_FIRST_RESPONSE_MS"
      else
        first_response=null
      fi
      anonymous_https="$(printf \
        '{"phase":%s,"seed_id":%s,"transport":"anonymous_https","outcome":%s,"first_response_ms":%s,"max_inactivity_ms":%s,"fetch_bytes":%s,"import_bytes":%s,"object_count":%s,"first_response_timeout_ms":2000,"inactivity_timeout_ms":10000,"hard_timeout_ms":120000}' \
        "$(phase_trace_json "$SEED_STARTED_AT_MS" "$SEED_DURATION_MS")" \
        "$(json_escape_value "$SEED_ID")" \
        "$seed_outcome" \
        "$first_response" \
        "$SEED_MAX_INACTIVITY_MS" \
        "$SEED_FETCH_BYTES" \
        "$SEED_IMPORT_BYTES" \
        "$SEED_OBJECT_COUNT")"
    fi
  fi
  printf \
    '{"schema_version":2,"plan_id":%s,"started_at_ms":%s,"finished_at_ms":%s,"access":%s,"git_runtime_wait":%s,"repo_target":%s,"anonymous_https":%s}' \
    "$(json_escape_value "$PLAN_ID")" \
    "$PREPARE_STARTED_AT_MS" \
    "$PREPARE_FINISHED_AT_MS" \
    "$access" \
    "$git_runtime_wait" \
    "$repo_target" \
    "$anonymous_https"
}

validate_completed_state() {
  ensure_ready || return 1
  if printf '%s' "$PLAN_JSON" | grep -q '"pre_workspace":null'; then
    return 0
  fi
  wait_for_git || return 1
  verify_repo_target || return 1
  staging="$(lease_home)/.remote-dev/seed-staging/$WORKSPACE_ID/$PLAN_ID"
  [ ! -e "$staging" ] || return 1
  [ ! -e "$(repo_path)/.git/remote-dev/control/git-seed-writer.lock" ] || return 1
  for pending in "$(repo_path)"/.git/objects/pack/*.next."$PLAN_ID"; do
    [ ! -e "$pending" ] || return 1
  done
  if [ -z "$SEED_HTTPS_URL$SEED_SSH_URL" ]; then
    [ "$(marker_field kind)" = not_requested ] || return 1
    return 0
  fi
  expected_seed_id="$(git_seed_id_v17)"
  [ "$(marker_field seed_id)" = "$expected_seed_id" ] || return 1
  seed_kind="$(marker_field kind)"
  case "$seed_kind" in
    ready)
      [ "$(marker_field fetched_oid)" = "$SEED_EXPECTED_OID" ] || return 1
      actual_seed="$(run_as_lease_user "$GIT_PATH" -C "$(repo_path)" rev-parse \
        --verify -q "refs/remote-dev/seeds/$expected_seed_id" 2>/dev/null)" || return 1
      [ "$actual_seed" = "$SEED_EXPECTED_OID" ] || return 1
      run_as_lease_user "$GIT_PATH" -C "$(repo_path)" \
        cat-file -e "$SEED_EXPECTED_OID^{commit}" >/dev/null 2>&1 || return 1
      ;;
    deferred)
      [ -n "$(marker_field reason_code)" ] || return 1
      ;;
    *) return 1 ;;
  esac
}

prepare_lease_v3() {
  load_prepare_plan
  PREPARE_STARTED_AT_MS="$(seed_now_ms)"
  [ ! -L "$HOME_ROOT" ] || fail "lease home root must not be a symlink"
  mkdir -p "$HOME_ROOT"
  acquire_prepare_lock
  marker="$(prepare_marker)"
  if [ -e "$marker" ]; then
    [ ! -L "$marker" ] && [ -f "$marker" ] && [ -r "$marker" ] || {
      emit_failed bind lease_prepare_marker_invalid not_started
      return 1
    }
    if [ "$TEST_MODE" = 0 ]; then
      marker_metadata="$(stat -c '%u:%g:%a' "$marker" 2>/dev/null || true)"
      [ "$marker_metadata" = 0:0:600 ] || {
        emit_failed bind lease_prepare_marker_invalid not_started
        return 1
      }
    fi
    marker_matches_identity || {
      emit_failed bind lease_prepare_plan_mismatch not_started
      return 1
    }
    case "$(marker_phase)" in
      bound|access_ready|repo_target_ready|complete) ;;
      *)
        emit_failed bind lease_prepare_marker_invalid not_started
        return 1
        ;;
    esac
  else
    write_prepare_marker bound
  fi
  resume_phase="$(marker_phase)"
  if [ "$resume_phase" = complete ]; then
    validate_completed_state || {
      emit_failed complete completed_state_invalid failed
      return 1
    }
    receipt="$(marker_receipt)" || {
      emit_failed complete receipt_missing failed
      return 1
    }
    execution_trace="$(stored_prepare_trace)" || {
      emit_failed complete execution_trace_missing failed
      return 1
    }
    emit_access_ready
    emit_completed "$receipt" "$execution_trace"
    return 0
  fi
  if [ "$(marker_field plan_id)" != "$PLAN_ID" ]; then
    emit_failed bind lease_prepare_plan_mismatch not_started
    return 1
  fi
  rm -f "$(prepare_trace)" "$(prepare_trace).next"
  ACCESS_STARTED_AT_MS="$(seed_now_ms)"
  if ! prepare_access_steps; then
    cleanup_access true >/dev/null 2>&1 || true
    emit_failed access access_prepare_failed cleaned
    return 1
  fi
  ACCESS_FINISHED_AT_MS="$(seed_now_ms)"
  ACCESS_DURATION_MS=$((ACCESS_FINISHED_AT_MS - ACCESS_STARTED_AT_MS))
  if [ "$resume_phase" != repo_target_ready ]; then
    write_prepare_marker access_ready
  fi
  emit_access_ready
  if printf '%s' "$PLAN_JSON" | grep -q '"pre_workspace":null'; then
    SEED_RESULT=not_requested
  else
    GIT_RUNTIME_WAIT_STARTED_AT_MS="$(seed_now_ms)"
    if ! wait_for_git; then
      cleanup_access true >/dev/null 2>&1 || true
      emit_failed git_runtime_wait git_runtime_wait_failed cleaned
      return 1
    fi
    GIT_RUNTIME_WAIT_FINISHED_AT_MS="$(seed_now_ms)"
    GIT_RUNTIME_WAIT_DURATION_MS=$((GIT_RUNTIME_WAIT_FINISHED_AT_MS \
      - GIT_RUNTIME_WAIT_STARTED_AT_MS))
    REPO_TARGET_STARTED_AT_MS="$(seed_now_ms)"
    if [ "$resume_phase" = repo_target_ready ]; then
      verify_repo_target || {
        cleanup_access true >/dev/null 2>&1 || true
        emit_failed repo_target repo_target_recovery_failed cleaned
        return 1
      }
    elif ! prepare_repo_target; then
      cleanup_access true >/dev/null 2>&1 || true
      emit_failed repo_target repo_target_failed cleaned
      return 1
    fi
    REPO_TARGET_FINISHED_AT_MS="$(seed_now_ms)"
    REPO_TARGET_DURATION_MS=$((REPO_TARGET_FINISHED_AT_MS - REPO_TARGET_STARTED_AT_MS))
    write_prepare_marker repo_target_ready
    if ! prepare_anonymous_seed; then
      cleanup_access true >/dev/null 2>&1 || true
      emit_failed git_seed_anonymous_https seed_process_join_failed cleaned
      return 1
    fi
  fi
  receipt="$(build_receipt)" || {
    cleanup_access true >/dev/null 2>&1 || true
    emit_failed complete receipt_build_failed cleaned
    return 1
  }
  PREPARE_FINISHED_AT_MS="$(seed_now_ms)"
  execution_trace="$(build_execution_trace)" || {
    cleanup_access true >/dev/null 2>&1 || true
    emit_failed complete execution_trace_build_failed cleaned
    return 1
  }
  write_prepare_trace "$execution_trace" || {
    cleanup_access true >/dev/null 2>&1 || true
    emit_failed complete execution_trace_write_failed cleaned
    return 1
  }
  write_prepare_marker complete "$receipt"
  emit_completed "$receipt" "$execution_trace"
}

usage() {
  fail "usage"
}

COMMAND="${1:-}"
[ -n "$COMMAND" ] || usage
shift

LEASE_ID=""
UNIX_USER=""
PUBLIC_KEY=""
INPUT_FILE=""
REMOVE_HOME=false # aws-embed-strip-line

while [ "$#" -gt 0 ]; do
  case "$1" in
    --lease-id)
      [ "$#" -ge 2 ] || usage
      LEASE_ID="$2"
      shift 2
      ;;
    --unix-user)
      [ "$#" -ge 2 ] || usage
      UNIX_USER="$2"
      shift 2
      ;;
    --input-file)
      [ "$#" -ge 2 ] || usage
      INPUT_FILE="$2"
      shift 2
      ;;
    # aws-embed-strip-begin
    --remove-home)
      REMOVE_HOME=true
      shift
      ;;
    # aws-embed-strip-end
    *)
      usage
      ;;
  esac
done

case "$COMMAND" in
  all)
    prepare_lease_v3
    ;;
  # aws-embed-strip-begin
  cleanup-access)
    [ -n "$LEASE_ID" ] || usage
    [ -n "$UNIX_USER" ] || usage
    cleanup_access "$REMOVE_HOME"
    ;;
  # aws-embed-strip-end
  *)
    fail "unsupported lease control command: $COMMAND"
    ;;
esac
